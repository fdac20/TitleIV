I delted a lot of files that contained info for different years. Find original dataset here https://collegescorecard.ed.gov/data/
